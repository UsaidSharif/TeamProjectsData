// src/app/invoice-form/invoice-form.component.ts
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { jsPDF } from 'jspdf';

@Component({
  selector: 'app-invoice-form',
  templateUrl: './invoice-form.component.html',
  styleUrls: ['./invoice-form.component.scss']
})
export class InvoiceFormComponent implements OnInit {
  invoiceForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.invoiceForm = this.fb.group({
      saleId: [''],
      saleDate: [''],
      season: [''],
      buyerName: [''],
      deliveryAddress: [''],
      hsCode: [''],
      efsCode: [''],
      gst: [''],
      ntn: [''],
      brokerName: [''],
      lots: this.fb.array([]),
      withholdingTax: [''],
      loading: [''],
      bciExpense: [''],
      netAmount: [''],
      salesTax: [''],
      incomeTax: [''],
      totalAmount: ['']
    });
  }

  ngOnInit(): void {
    this.addLot(); // Add initial lot
  }

  get lots(): FormArray {
    return this.invoiceForm.get('lots') as FormArray;
  }

  addLot() {
    const lot = this.fb.group({
      lotNo: [''],
      totalBales: [''],
      kgs: [''],
      mounds: [''],
      rate: [''],
      amount: ['']
    });
    this.lots.push(lot);
  }

  removeLot(index: number) {
    this.lots.removeAt(index);
  }

  onSubmit() {
    // Save the form data to local storage or a database
    console.log(this.invoiceForm.value);
  }

  generatePDF() {
    const pdf = new jsPDF('p', 'mm', 'a4');
    const invoiceData = this.invoiceForm.value;

    // Header
    pdf.setFontSize(20);
    pdf.setTextColor(40);
    pdf.text('Modern Cotton Factory & Oil Mills', 10, 10);
    
    pdf.setFontSize(12);
    pdf.text('GHALLAH MANDI SHOP-6 BLOCK-C, HAROONABAD.', 10, 18);
    pdf.text('GST: 04-01-5201-669-37    NTN: 2280937-6', 10, 24);

    pdf.setFontSize(14);
    pdf.setTextColor(0);
    pdf.text('Lint Sale Bill', 10, 32);

    pdf.setLineWidth(0.5);
    pdf.line(10, 35, 200, 35); // Horizontal line

    // Sale Information
    pdf.setFontSize(12);
    pdf.setTextColor(40);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Sale Information', 10, 42);

    pdf.setFont('helvetica', 'normal');
    pdf.setTextColor(0);
    pdf.text(`Sale ID: ${invoiceData.saleId}`, 10, 50);
    pdf.text(`Sale Date: ${invoiceData.saleDate}`, 70, 50);
    pdf.text(`Season: ${invoiceData.season}`, 130, 50);

    // Buyer Information
    pdf.setTextColor(40);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Buyer Information', 10, 58);

    pdf.setFont('helvetica', 'normal');
    pdf.setTextColor(0);
    pdf.text(`Buyer Name: ${invoiceData.buyerName}`, 10, 66);
    pdf.text(`Delivery Address: ${invoiceData.deliveryAddress}`, 70, 66);

    // Additional Information
    pdf.setTextColor(40);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Additional Information', 10, 74);

    pdf.setFont('helvetica', 'normal');
    pdf.setTextColor(0);
    pdf.text(`HS Code: ${invoiceData.hsCode}`, 10, 82);
    pdf.text(`EFS Code: ${invoiceData.efsCode}`, 70, 82);
    pdf.text(`GST: ${invoiceData.gst}`, 130, 82);
    pdf.text(`NTN: ${invoiceData.ntn}`, 190, 82, { align: 'right' });

    pdf.text(`Broker Name: ${invoiceData.brokerName}`, 10, 90);

    // Invoice Details
    let currentY = 98;
    pdf.setTextColor(40);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Invoice Details', 10, currentY);

    currentY += 10;
    pdf.setFillColor(200, 200, 200);
    pdf.rect(10, currentY - 5, 190, 8, 'F');
    pdf.setFontSize(10);
    pdf.setTextColor(0);
    pdf.setFont('helvetica', 'bold');
    pdf.text('Lot No', 12, currentY);
    pdf.text('Total Bales', 40, currentY);
    pdf.text('Kg\'s', 80, currentY);
    pdf.text('Mounds', 110, currentY);
    pdf.text('Rate', 140, currentY);
    pdf.text('Amount', 170, currentY);

    currentY += 10;
    pdf.setFont('helvetica', 'normal');
    invoiceData.lots.forEach((lot: any, index: number) => {
        pdf.text(`${lot.lotNo}`, 12, currentY);
        pdf.text(`${lot.totalBales}`, 40, currentY);
        pdf.text(`${lot.kgs}`, 80, currentY);
        pdf.text(`${lot.mounds}`, 110, currentY);
        pdf.text(`${lot.rate}`, 140, currentY);
        pdf.text(`${lot.amount}`, 170, currentY);
        currentY += 10;
    });

    // Totals and Taxes
    currentY += 10;
    pdf.setFont('helvetica', 'bold');
    pdf.setTextColor(40);
    pdf.text('Summary', 10, currentY);

    currentY += 10;
    pdf.setFontSize(12);
    pdf.setTextColor(0);
    pdf.setFont('helvetica', 'normal');
    pdf.text(`Withholding Tax: ${invoiceData.withholdingTax}`, 10, currentY);
    pdf.text(`Loading: ${invoiceData.loading}`, 70, currentY);
    pdf.text(`BCI Expense: ${invoiceData.bciExpense}`, 130, currentY);

    currentY += 10;
    pdf.text(`Net Amount: ${invoiceData.netAmount}`, 10, currentY);
    pdf.text(`Sales Tax: ${invoiceData.salesTax}`, 70, currentY);
    pdf.text(`Income Tax: ${invoiceData.incomeTax}`, 130, currentY);

    currentY += 10;
    pdf.setFont('helvetica', 'bold');
    pdf.setTextColor(0);
    pdf.text(`Total Amount: ${invoiceData.totalAmount}`, 10, currentY);

    // Footer
    pdf.setFontSize(10);
    pdf.setTextColor(150);
    pdf.setFont('helvetica', 'italic');
    pdf.text('Thank you for your business!', 10, 290);
    pdf.setFont('helvetica', 'normal');
    pdf.text('If you have any questions about this invoice, please contact us.', 10, 295);

    pdf.save('invoice.pdf');
}


}
