const express = require('express');
const axios = require('axios');
const cors = require('cors');
const app = express();

app.use(cors()); // Enables CORS

const PORT = 3000;

app.get('/fetch-url', async (req, res) => {
  const targetUrl = req.query.url;
  if (!targetUrl) {
    return res.status(400).send('URL parameter is required');
  }

  // Validate the URL or limit to specific domains to prevent SSRF
  // if (!isValidUrl(targetUrl)) {
  //   return res.status(400).send('Invalid URL');
  // }

  try {
    const response = await axios.get(targetUrl, {
      headers: {
        'User-Agent': 'My Proxy Service'
      }
    });
    res.send(response.data);
  } catch (error) {
    res.status(500).json({ status: 'error', message: error.message });
  }
});

function isValidUrl(url) {
  const validDomains = ['https://service2.diplo.de', 'https://example.com'];
  return validDomains.some(domain => url.startsWith(domain));
}

app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});
