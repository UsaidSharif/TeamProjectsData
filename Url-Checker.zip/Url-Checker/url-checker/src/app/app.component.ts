import { Component } from '@angular/core';
import { UrlCheckService } from './url-check.service';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  url: string = '';
  htmlContent: string = '';
  sanitizedHtmlContent: SafeUrl = '';
  message: string = '';
  intervalId: any; // To store interval ID for clearing
  audio = new Audio('assets/alert.mp3'); // Path to your audio file
  constructor(
    private urlCheckService: UrlCheckService,
    private sanitizer: DomSanitizer
  ) {}

  fetchHtml(): void {
    this.urlCheckService.fetchUrl(this.url).subscribe({
      next: (data) => {
        this.htmlContent = data;
        this.sanitizedHtmlContent =
          this.sanitizer.bypassSecurityTrustResourceUrl(
            `data:text/html;charset=UTF-8,${encodeURIComponent(data)}`
          );
        if (
          data.includes(
            'Bei der Bearbeitung Ihrer Buchung ist ein Fehler aufgetreten'
          )
        ) {
          this.showMessage('Appointments are not open till yet, baby!');
        } else {
          this.showMessage('Appointments are open! Hurry Up Fill the form');
          this.playSound();
        }
      },
      error: (error) => {
        console.error('Error fetching HTML:', error);
        this.showMessage(
          "Oops, couldn't fetch the data. Please try again later."
        );
      },
    });
  }

  showMessage(msg: string): void {
    this.message = msg;
    setTimeout(() => {
      this.message = '';
      this.audio.pause();
      this.audio.currentTime = 0;
    }, 5000); // Hide message after 5 seconds
  }

  startChecking(): void {
    this.fetchHtml(); // Initial check
    this.intervalId = setInterval(() =>{
      this.fetchHtml()
    } , 10000); // Continue checking every 10 seconds
  }

  ngOnDestroy(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId); // Clear the interval when the component is destroyed
    }
  }

  playSound(): void {
    this.audio.play();
  }
}
