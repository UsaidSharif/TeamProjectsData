import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class UrlCheckService {

  private proxyEndpoint = 'http://localhost:3000/fetch-url';

  constructor(private http: HttpClient) { }

  fetchUrl(targetUrl: string): Observable<string> {
    return this.http.get(`${this.proxyEndpoint}?url=${encodeURIComponent(targetUrl)}`, { responseType: 'text' });
  }

}
